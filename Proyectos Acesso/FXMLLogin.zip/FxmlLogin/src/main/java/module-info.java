module com.mycompany.fxmllogin {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.fxmllogin to javafx.fxml;
    exports com.mycompany.fxmllogin;
}
