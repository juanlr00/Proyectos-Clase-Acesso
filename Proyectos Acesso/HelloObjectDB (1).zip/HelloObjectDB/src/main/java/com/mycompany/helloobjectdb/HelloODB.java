/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.helloobjectdb;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import models.NewClass;

/**
 *
 * @author DavidGonzalezMartíne
 */
public class HelloODB {

    static EntityManagerFactory emf;
    
    
    public static void main(String[] args) {
        
        try{
        emf = Persistence.createEntityManagerFactory("datos.odb");
        } catch(Exception ex){
            System.out.println("Error al iniciar EntityManagerFactory");
        }
        
    
    
    EntityManager em = emf.createEntityManager();
    
    NewClass ready = new NewClass();
    ready.setName("Francisco");
    ready.setPosition("Profesor");
    ready.setTeam("2DAM");
    ready.setMoney(999.9);
    
    em.getTransaction().begin();
    em.persist(ready);
    em.getTransaction().commit();
    
    

        
    TypedQuery<models.NewClass> q = em.createQuery("SELECT p FROM NewClass p", models.NewClass.class);
    var resultado = q.getResultList();
    
        System.out.println("Todo el contenido");
    resultado.forEach( (p)->System.out.println(p) );
    
        System.out.println("\n\nLos mayores de 6");
    resultado.forEach( (p)->System.out.println(p) );
    
    
    
    }
}