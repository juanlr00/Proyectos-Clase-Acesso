package com.mycompany.skyranger;

import models.Constellation;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class SkyDAO {

    private SessionFactory sessionFactory;

    public SkyDAO() {
        try {
            sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (HibernateException ex) {
            System.out.println("Error al crear SessionFactory");
            System.out.println(ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public void saveConstellation(Constellation c) {
        Session s = sessionFactory.openSession();
        Transaction t = s.beginTransaction();
        s.saveOrUpdate(c);
        t.commit();
        s.close();
    }

    public void printSky(String h, String lan) {
        Session s = sessionFactory.openSession();

        Query<Constellation> q = s.createQuery("from Constellation c where c.location=:loc", Constellation.class);
        q.setParameter("loc", h);
        var sky = q.list();

        if (lan == "es") {
            System.out.println("\n\nCielo " + h + " ");
        } else if (lan == "en") {
            System.out.println("\n\n" + h + " sky:");
        }
        sky.forEach((c) -> {
            if (lan == "es") {
                System.out.println(c.getTranslation().getEs());
                System.out.println("Estrellas:");
            } else if (lan == "en") {
                System.out.println(c.getTranslation().getEn());
                System.out.println("Stars:");
            }
            c.getStars().forEach((st) -> {
                System.out.println(st);
            });
        });

        s.close();
    }
}
