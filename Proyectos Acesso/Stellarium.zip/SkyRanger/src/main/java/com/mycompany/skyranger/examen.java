package com.mycompany.skyranger;

import models.Constellation;
import models.Star;
import models.Translation;

public class examen {

    public static void main(String[] args) {
        SkyDAO sky = new SkyDAO();
        
//        Constellation UrsaMaior = new Constellation();
//        UrsaMaior.setName("UrsaMaior");
//        UrsaMaior.setLocation("Boreal");
//        UrsaMaior.setTranslation( new Translation("Osa mayor","North Bear") );
//        
//        Star polaris = new Star("Polaris",1.0);
//  
//        UrsaMaior.addStar(polaris);
//        UrsaMaior.addStar( new Star("Borealis",2.0) );
//  
//        System.out.println(UrsaMaior);
//        System.out.println(UrsaMaior.getStars());
//        
//        sky.saveConstellation(UrsaMaior);
        sky.printSky("Boreal","en");
    }
    
}
