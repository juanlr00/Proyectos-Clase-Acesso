package models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity 
@Table(name="constellation") 
public class Constellation implements Serializable {
    @Id
    @GeneratedValue( strategy = IDENTITY)
    private Long id;
    private String name;
    private String location;
    
    @OneToMany( mappedBy = "constellation", cascade=CascadeType.ALL )
    private Set<Star> stars = new HashSet(0);
    
    @OneToOne( cascade=CascadeType.ALL)
    @JoinColumn( name="translation_id")
    private Translation translation;
    
    
    public Constellation() {
    }

    public Constellation(String name, String location) {
        this.name = name;
        this.location = location;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Set<Star> getStars() {
        return stars;
    }

    public void setStars(Set<Star> stars) {
        this.stars = stars;
    }
    
    public void addStar( Star star ){
        stars.add(star);
        star.setConstellation(this);
    }

    public Translation getTranslation() {
        return translation;
    }

    public void setTranslation(Translation translation) {
        this.translation = translation;
    }

    @Override
    public String toString() {
        return "Constellation{" + "id=" + id + ", name=" + name + ", location=" + location + '}';
    }

    

}
