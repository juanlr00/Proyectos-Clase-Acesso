
package models;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="star")
public class Star implements Serializable {

    @Id
    @GeneratedValue( strategy = IDENTITY)
    private Long id;
    private String name;
    private Double magnitude;
    
    @ManyToOne
    @JoinColumn( name="constellation_id")
    private Constellation constellation;

    public Star() {
    }

    public Star(String name, Double magnitude) {
        this.name = name;
        this.magnitude = magnitude;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(Double magnitude) {
        this.magnitude = magnitude;
    }

    public Constellation getConstellation() {
        return constellation;
    }

    public void setConstellation(Constellation constellation) {
        this.constellation = constellation;
    }

    @Override
    public String toString() {
        return "Star{" + "id=" + id + 
                ", name=" + name + 
                ", magnitude=" + magnitude + 
                ", constellation=" + constellation.getName() + '}';
    }


    
}
